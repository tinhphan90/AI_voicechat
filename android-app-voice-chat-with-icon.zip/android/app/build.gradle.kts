plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.trolyrobot.ai"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.trolyrobot.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        debug {
            buildConfigField("String", "SERVER_URL", "\"wss://ais-dev-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
            buildConfigField("String", "DEV_SERVER_URL", "\"wss://ais-dev-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
            buildConfigField("String", "PRODUCTION_SERVER_URL", "\"wss://ais-pre-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
        }
        release {
            isMinifyEnabled = false
            buildConfigField("String", "SERVER_URL", "\"wss://ais-pre-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
            buildConfigField("String", "DEV_SERVER_URL", "\"wss://ais-dev-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
            buildConfigField("String", "PRODUCTION_SERVER_URL", "\"wss://ais-pre-5xajsiegcuhelan7xhiauy-405599943963.asia-southeast1.run.app/ws\"")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.11"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    // Compose BOM
    implementation(platform("androidx.compose:compose-bom:2024.03.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Navigation & ViewModel
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")

    // OkHttp & Gson for WebSockets & REST APIs
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.google.code.gson:gson:2.10.1")

    // Coil for Image Loading in Compose
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.0")

    // Testing
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.03.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
